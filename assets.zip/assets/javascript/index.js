function goToDonation() {
    const element = document.getElementById("Donation");
    element.scrollIntoView(true);
    return false;
}